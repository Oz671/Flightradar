const express = require("express");
const http = require("http");
const socketIo = require("socket.io");
const fetch = require('node-fetch');

const port = process.env.PORT || 4001;
const index = require("./routes/index");

const app = express();
app.use(index);

const server = http.createServer(app);

const io = socketIo(server, {
  cors: {
    origin: '*',
  }
});

let interval;

io.on("connection", (socket) => {
  console.log("New client connected");
  if (interval) {
    clearInterval(interval);
  }
  interval = setInterval(() => getApiAndEmit(socket), 1000);
  socket.on("disconnect", () => {
    console.log("Client disconnected");
    clearInterval(interval);
  });
});

const getApiAndEmit = socket => {
  var url = "https://data-cloud.flightradar24.com/zones/fcgi/feed.js?faa=1&bounds=41.449%2C21.623%2C16.457%2C53.063&satellite=1&mlat=1&flarm=1&adsb=1&gnd=1&air=1&vehicles=1&estimated=1&maxage=14400&gliders=1&stats=1"
  let settings = { method: "Get" };

  fetch(url, settings)
    .then(res => res.json())
    .then((json) => {
        // do something with JSON
        //console.log(json)

        let total = 0;
        let locations = [];
        for(const k in json)
        {
          if (typeof(json[k]) == "object") {
            const v = json[k];

            if(v[12] == "TLV" || v[13] == "TLV") {
              total += 1;
              console.log(v[1], v[2])
              locations.push([v[1], v[2]]);
            }
          }
        }

        // Emitting a new message. Will be consumed by the client
        socket.emit("FromAPI", {
          total,
          locations
        });
        
    });

};

server.listen(port, () => console.log(`Listening on port ${port}`));