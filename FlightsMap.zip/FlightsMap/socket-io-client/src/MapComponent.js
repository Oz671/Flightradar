import React from "react";
import BingMapsReact from "bingmaps-react";

const MapComponent = (props) => {
  const key = "AlzZYgCV7bIhpLrkWoMhNtmLjj9mvC28Rwga3z-sjmWwrdL1Ne6M5hpFZUktu2JJ";

  const pushPins = props.locations?.map(x => {
    return {
        center: {
            latitude: x[0],
            longitude: x[1],
          },
          options: {
            title: "",
          },
    }
  })

  return (
    <BingMapsReact
      pushPins={pushPins}
      bingMapsKey={key}
      height="600px"
      mapOptions={{
        navigationBarMode: "square",
      }}
      width="600px"
      viewOptions={{
        center: { latitude: 31.771959, longitude: 35.217018 },
        zoom: 5,
        mapTypeId: "canvasLight",
      }}
    />
  );
}

export default MapComponent;
